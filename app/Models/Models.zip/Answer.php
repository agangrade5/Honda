<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Answer extends Model
{
    protected $table = 'answers';

    protected $primaryKey = 'answerid';

    public $timestamps = false;

    protected $guarded = [];
}
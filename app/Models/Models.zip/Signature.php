<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Signature extends Model
{
    protected $table = 'signatures';

    protected $primaryKey = 'sigid';

    public $timestamps = false;

    protected $guarded = [];
}
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('apikeys', function (Blueprint $table) {
            $table->string('apikey', 100);
            $table->bigInteger('clientid')->nullable();
            $table->dateTime('apilastaccess')->nullable();
            $table->boolean('apiallowaccess')->nullable();
            $table->boolean('recordstatus');
            $table->primary('apikey');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('apikeys');
    }
};